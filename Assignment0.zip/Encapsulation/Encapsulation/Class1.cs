﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Encapsulation
{

    class Person
    {
        public string Name    // property
        { get; set; }
    }
}
