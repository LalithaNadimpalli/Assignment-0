﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Inheritance
{
    class Car : Vehicle  // Derived class
    {
        public string modelName = "Mustang";  // Car field
    }
}
